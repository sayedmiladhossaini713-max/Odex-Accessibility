package com.revayateyekdel.audexnext;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Audex Next");
        title.setTextSize(28);
        title.setContentDescription("Audex Next");
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("این برنامه کنترل‌های بدون برچسب را تشخیص می‌دهد و نام حدسی آن‌ها را اعلام می‌کند. پس از فعال‌کردن سرویس، TalkBack را روشن نگه دارید.");
        info.setTextSize(18);
        info.setPadding(0, pad, 0, pad);
        root.addView(info);

        Button open = new Button(this);
        open.setText("باز کردن تنظیمات دسترس‌پذیری");
        open.setContentDescription("باز کردن تنظیمات دسترس‌پذیری و فعال کردن Audex Next");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(open);

        Button tts = new Button(this);
        tts.setText("تنظیمات تبدیل متن به گفتار");
        tts.setContentDescription("باز کردن تنظیمات تبدیل متن به گفتار");
        tts.setOnClickListener(v -> {
            try {
                startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        root.addView(tts);

        setContentView(root);
    }
}
