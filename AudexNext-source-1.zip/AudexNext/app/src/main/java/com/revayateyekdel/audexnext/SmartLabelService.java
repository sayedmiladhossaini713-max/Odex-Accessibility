package com.revayateyekdel.audexnext;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class SmartLabelService extends AccessibilityService implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private boolean ready;
    private String lastAnnouncement = "";
    private long lastTime;

    private static final Map<String, String> TOKENS = new HashMap<>();
    static {
        TOKENS.put("back", "بازگشت");
        TOKENS.put("close", "بستن");
        TOKENS.put("menu", "منو");
        TOKENS.put("more", "گزینه‌های بیشتر");
        TOKENS.put("search", "جستجو");
        TOKENS.put("share", "اشتراک‌گذاری");
        TOKENS.put("send", "ارسال");
        TOKENS.put("play", "پخش");
        TOKENS.put("pause", "توقف موقت");
        TOKENS.put("next", "بعدی");
        TOKENS.put("previous", "قبلی");
        TOKENS.put("camera", "دوربین");
        TOKENS.put("gallery", "گالری");
        TOKENS.put("image", "تصویر");
        TOKENS.put("video", "ویدیو");
        TOKENS.put("download", "دانلود");
        TOKENS.put("delete", "حذف");
        TOKENS.put("edit", "ویرایش");
        TOKENS.put("save", "ذخیره");
        TOKENS.put("add", "افزودن");
        TOKENS.put("home", "خانه");
        TOKENS.put("profile", "نمایه");
        TOKENS.put("settings", "تنظیمات");
        TOKENS.put("favorite", "علاقه‌مندی");
        TOKENS.put("like", "پسندیدن");
        TOKENS.put("comment", "نظرها");
        TOKENS.put("refresh", "تازه‌سازی");
        TOKENS.put("clear", "پاک کردن");
        TOKENS.put("cancel", "لغو");
        TOKENS.put("confirm", "تأیید");
        TOKENS.put("done", "انجام شد");
        TOKENS.put("record", "ضبط");
        TOKENS.put("mic", "میکروفون");
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            int result = tts.setLanguage(new Locale("fa", "IR"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            tts.setSpeechRate(1.05f);
            ready = true;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!ready || event == null) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED &&
            type != AccessibilityEvent.TYPE_VIEW_FOCUSED) return;

        AccessibilityNodeInfo node = event.getSource();
        if (node == null) return;
        try {
            if (hasUsefulLabel(node) || !isInteractive(node)) return;
            String label = inferLabel(node);
            if (!TextUtils.isEmpty(label)) announce(label);
        } finally {
            node.recycle();
        }
    }

    private boolean hasUsefulLabel(AccessibilityNodeInfo node) {
        return nonEmpty(node.getText()) || nonEmpty(node.getContentDescription()) || nonEmpty(node.getHintText()) || nonEmpty(node.getStateDescription());
    }

    private boolean isInteractive(AccessibilityNodeInfo node) {
        return node.isClickable() || node.isLongClickable() || node.isCheckable() ||
            classEnds(node, "Button") || classEnds(node, "ImageButton") || classEnds(node, "CheckBox") || classEnds(node, "Switch");
    }

    private boolean classEnds(AccessibilityNodeInfo node, String suffix) {
        CharSequence c = node.getClassName();
        return c != null && c.toString().endsWith(suffix);
    }

    private String inferLabel(AccessibilityNodeInfo node) {
        String id = node.getViewIdResourceName();
        String fromId = labelFromId(id);
        if (!TextUtils.isEmpty(fromId)) return fromId + "، برچسب پیشنهادی";

        String nearby = nearbyText(node);
        if (!TextUtils.isEmpty(nearby)) return nearby + "، دکمه بدون برچسب";

        if (node.isCheckable()) return node.isChecked() ? "گزینه انتخاب‌شده بدون برچسب" : "گزینه انتخاب‌نشده بدون برچسب";
        if (classEnds(node, "ImageButton")) return "دکمه تصویری بدون برچسب";
        if (classEnds(node, "Button")) return "دکمه بدون برچسب";
        return "کنترل بدون برچسب";
    }

    private String labelFromId(String id) {
        if (TextUtils.isEmpty(id)) return "";
        String value = id;
        int slash = value.lastIndexOf('/');
        if (slash >= 0 && slash + 1 < value.length()) value = value.substring(slash + 1);
        value = value.toLowerCase(Locale.ROOT).replace('-', '_');
        String[] parts = value.split("_");
        List<String> translated = new ArrayList<>();
        for (String p : parts) {
            String t = TOKENS.get(p);
            if (t != null && !translated.contains(t)) translated.add(t);
        }
        if (!translated.isEmpty()) return TextUtils.join(" ", translated);
        return "";
    }

    private String nearbyText(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo parent = node.getParent();
        if (parent == null) return "";
        try {
            int count = Math.min(parent.getChildCount(), 12);
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = parent.getChild(i);
                if (child == null) continue;
                try {
                    if (child.equals(node)) continue;
                    CharSequence text = firstNonEmpty(child.getText(), child.getContentDescription(), child.getHintText());
                    if (nonEmpty(text) && text.length() <= 60) return text.toString();
                } finally {
                    child.recycle();
                }
            }
        } finally {
            parent.recycle();
        }
        return "";
    }

    private CharSequence firstNonEmpty(CharSequence... values) {
        for (CharSequence v : values) if (nonEmpty(v)) return v;
        return "";
    }

    private boolean nonEmpty(CharSequence value) {
        return value != null && value.toString().trim().length() > 0;
    }

    private void announce(String text) {
        long now = System.currentTimeMillis();
        if (text.equals(lastAnnouncement) && now - lastTime < 1800) return;
        lastAnnouncement = text;
        lastTime = now;
        Bundle params = new Bundle();
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "audex_" + now);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "audex_" + now);
    }

    @Override
    public void onInterrupt() {
        if (tts != null) tts.stop();
    }

    @Override
    public void onDestroy() {
        ready = false;
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
